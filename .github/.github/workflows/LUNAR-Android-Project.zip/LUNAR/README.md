# LUNAR Music (Android project starter)

A dark Liquid Glass-inspired music-player UI concept for Android, with a Media3 playback service foundation.

## Included
- Jetpack Compose UI with blurred ambient gradients, glass-like panels, album-art placeholder, animated pulse, playback controls, lyrics panel, and speed slider concept.
- Android Media3 `MediaSessionService` foundation for background playback integration.
- Android project configured for Gradle / Android Studio.

## Important status
This is a **starter project**, not a finished APK. The current screen is a UI prototype: the demo track and lyrics are placeholders, the progress slider and previous/next controls are not wired to a local music library, and the speed slider is visual only. A full implementation still needs media-library scanning, actual player connection and queue, audio-speed/pitch processing, synchronized lyric loading/provider integration, artwork extraction and palette generation, notification permission handling, and device testing. Build with Android Studio using a compatible Android SDK and Gradle installation.
