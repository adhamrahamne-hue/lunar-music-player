package com.lunar.music

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF090912)
private val Lavender = Color(0xFFBFA2FF)
private val Ice = Color(0xFF9CEBFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LunarScreen() }
    }
}

@Composable
private fun LunarScreen() {
    var playing by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(true) }
    var speed by remember { mutableFloatStateOf(1f) }
    val transition = rememberInfiniteTransition(label = "ambient")
    val pulse by transition.animateFloat(
        initialValue = 0.96f, targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(2800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )

    Box(Modifier.fillMaxSize().background(Night)) {
        Box(Modifier.fillMaxWidth().height(500.dp).align(Alignment.TopCenter).blur(95.dp)
            .background(Brush.radialGradient(listOf(Color(0xFF5942A5).copy(alpha = .8f), Color(0xFF163D61).copy(alpha = .35f), Color.Transparent))))
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 22.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 20.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("L U N A R", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("YOUR MUSIC, IN ANOTHER LIGHT", color = Color(0xFFB7B0CC), fontSize = 9.sp, letterSpacing = 1.5.sp)
                }
                GlassIcon(Icons.Default.GraphicEq, "Audio tools")
            }

            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Box(Modifier.size(265.dp).scale(pulse).background(Brush.radialGradient(listOf(Lavender.copy(alpha = .34f), Ice.copy(alpha = .12f), Color.Transparent)), CircleShape).blur(24.dp))
                Box(Modifier.size(232.dp).background(Brush.linearGradient(listOf(Color(0xFF47396D), Color(0xFF182E4C), Color(0xFF171321))), RoundedCornerShape(30.dp)).border(1.dp, Color.White.copy(alpha = .22f), RoundedCornerShape(30.dp)), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("☾", color = Color.White, fontSize = 94.sp, lineHeight = 100.sp)
                        Text("MOONLIT", color = Color.White.copy(alpha = .85f), fontSize = 12.sp, letterSpacing = 4.sp)
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Midnight Memories", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                    Text("Lunar Sessions · Demo track", color = Color(0xFFBDB6CF), fontSize = 14.sp)
                }
                GlassIcon(Icons.Default.FavoriteBorder, "Favorite")
            }
            Spacer(Modifier.height(18.dp))
            Column {
                Slider(value = .38f, onValueChange = {}, colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Lavender, inactiveTrackColor = Color.White.copy(alpha = .18f)))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("1:24", color = Color(0xFFAAA3BC), fontSize = 11.sp)
                    Text("3:42", color = Color(0xFFAAA3BC), fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {}) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
                Box(Modifier.size(66.dp).background(Brush.linearGradient(listOf(Lavender, Ice)), CircleShape), contentAlignment = Alignment.Center) {
                    IconButton(onClick = { playing = !playing }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pause" else "Play", tint = Night, modifier = Modifier.size(38.dp)) }
                }
                IconButton(onClick = {}) { Icon(Icons.Default.SkipNext, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
            }
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("LYRICS", color = Color.White, fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = { showLyrics = !showLyrics }) { Text(if (showLyrics) "Hide" else "Show", color = Lavender) }
            }
            AnimatedVisibility(visible = showLyrics) {
                Column(Modifier.fillMaxWidth().background(Color.White.copy(alpha = .055f), RoundedCornerShape(24.dp)).border(1.dp, Color.White.copy(alpha = .13f), RoundedCornerShape(24.dp)).padding(18.dp)) {
                    Text("When the city falls asleep", color = Color.White.copy(alpha = .46f), fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(8.dp))
                    Text("we find our own kind of light", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("and let the silence move", color = Color.White.copy(alpha = .46f), fontSize = 16.sp)
                    Text("Demo lyrics · Replace with synced song lyrics", color = Color(0xFFB8ACD8), fontSize = 10.sp, modifier = Modifier.padding(top = 12.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().background(Color.White.copy(alpha = .06f), RoundedCornerShape(18.dp)).border(1.dp, Color.White.copy(alpha = .12f), RoundedCornerShape(18.dp)).padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("SPEED", color = Color.White, fontSize = 11.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.width(10.dp))
                Slider(value = speed, onValueChange = { speed = it }, valueRange = .5f..2f, modifier = Modifier.weight(1f), colors = SliderDefaults.colors(thumbColor = Ice, activeTrackColor = Ice, inactiveTrackColor = Color.White.copy(alpha = .15f)))
                Text("${"%.2f".format(speed)}×", color = Ice, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Text("LUNAR · UI CONCEPT", color = Color(0xFF6F687F), fontSize = 9.sp, letterSpacing = 2.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp))
        }
    }
}

@Composable
private fun GlassIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String) {
    Box(Modifier.size(44.dp).background(Color.White.copy(alpha = .075f), CircleShape).border(1.dp, Color.White.copy(alpha = .18f), CircleShape), contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = description, tint = Color.White, modifier = Modifier.size(21.dp))
    }
}
